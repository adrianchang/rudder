
import React from 'react';
import ReactDOM from 'react-dom';
import './css/index.css';
import firebase from 'firebase';

class LoginPage extends React.Component{
    componentDidMount(){
        console.log("LoginPage");
    }

    render(){
        console.log("LoginPage render");
        return (
            <div className="backgroundImage"></div>          
        );
    }
}

ReactDOM.render(
    <LoginPage/>,
    document.getElementById('mount-point')
);